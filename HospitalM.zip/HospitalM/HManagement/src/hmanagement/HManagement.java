
package hmanagement;
import java.util.Scanner;

/**
 *
 * @author Anjula
 */
public abstract class HManagement {
    String doctors[]={"Nishan","Ahamed","Ravi","Subash"};
   
    abstract void viewDct(); 
    abstract void addBooking();
    abstract void addPation();
    abstract void viewPation();
}
